# php-excel-reader-2-21
``` 
Original code from:
https://code.google.com/p/php-excel-reader/
```

I found a problem in original code. But you don't worry because now I have fix that problem.

### Version
v.2.21

### Support
PHP version >= 5.3 && version < 7

> Actually for php 7.x I still hesitate, because I also have never tried it.
